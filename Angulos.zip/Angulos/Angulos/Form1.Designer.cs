﻿
namespace Angulos
{
    partial class FrmAngulos
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAngulo1 = new System.Windows.Forms.Label();
            this.lblAngulo2 = new System.Windows.Forms.Label();
            this.lblAngulo3 = new System.Windows.Forms.Label();
            this.txtAngulo1 = new System.Windows.Forms.TextBox();
            this.txtAngulo2 = new System.Windows.Forms.TextBox();
            this.txtAngulo3 = new System.Windows.Forms.TextBox();
            this.btnClassificar = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAngulo1
            // 
            this.lblAngulo1.AutoSize = true;
            this.lblAngulo1.Location = new System.Drawing.Point(9, 17);
            this.lblAngulo1.Name = "lblAngulo1";
            this.lblAngulo1.Size = new System.Drawing.Size(146, 13);
            this.lblAngulo1.TabIndex = 0;
            this.lblAngulo1.Text = "Digite a medida do 1º ângulo:";
            // 
            // lblAngulo2
            // 
            this.lblAngulo2.AutoSize = true;
            this.lblAngulo2.Location = new System.Drawing.Point(9, 68);
            this.lblAngulo2.Name = "lblAngulo2";
            this.lblAngulo2.Size = new System.Drawing.Size(146, 13);
            this.lblAngulo2.TabIndex = 1;
            this.lblAngulo2.Text = "Digite a medida do 2º ângulo:";
            // 
            // lblAngulo3
            // 
            this.lblAngulo3.AutoSize = true;
            this.lblAngulo3.Location = new System.Drawing.Point(9, 121);
            this.lblAngulo3.Name = "lblAngulo3";
            this.lblAngulo3.Size = new System.Drawing.Size(146, 13);
            this.lblAngulo3.TabIndex = 2;
            this.lblAngulo3.Text = "Digite a medida do 3º ângulo:";
            // 
            // txtAngulo1
            // 
            this.txtAngulo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAngulo1.Location = new System.Drawing.Point(173, 8);
            this.txtAngulo1.Name = "txtAngulo1";
            this.txtAngulo1.Size = new System.Drawing.Size(100, 31);
            this.txtAngulo1.TabIndex = 3;
            this.txtAngulo1.Text = "0";
            this.txtAngulo1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAngulo2
            // 
            this.txtAngulo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAngulo2.Location = new System.Drawing.Point(173, 55);
            this.txtAngulo2.Name = "txtAngulo2";
            this.txtAngulo2.Size = new System.Drawing.Size(100, 31);
            this.txtAngulo2.TabIndex = 4;
            this.txtAngulo2.Text = "0";
            this.txtAngulo2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtAngulo3
            // 
            this.txtAngulo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAngulo3.Location = new System.Drawing.Point(173, 112);
            this.txtAngulo3.Name = "txtAngulo3";
            this.txtAngulo3.Size = new System.Drawing.Size(100, 31);
            this.txtAngulo3.TabIndex = 5;
            this.txtAngulo3.Text = "0";
            this.txtAngulo3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnClassificar
            // 
            this.btnClassificar.BackColor = System.Drawing.Color.Lime;
            this.btnClassificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClassificar.Location = new System.Drawing.Point(12, 159);
            this.btnClassificar.Name = "btnClassificar";
            this.btnClassificar.Size = new System.Drawing.Size(261, 49);
            this.btnClassificar.TabIndex = 6;
            this.btnClassificar.Text = "CLASSIFICAR";
            this.btnClassificar.UseVisualStyleBackColor = false;
            this.btnClassificar.Click += new System.EventHandler(this.btnClassificar_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblResultado.Location = new System.Drawing.Point(9, 235);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(264, 43);
            this.lblResultado.TabIndex = 7;
            this.lblResultado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmAngulos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(285, 290);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnClassificar);
            this.Controls.Add(this.txtAngulo3);
            this.Controls.Add(this.txtAngulo2);
            this.Controls.Add(this.txtAngulo1);
            this.Controls.Add(this.lblAngulo3);
            this.Controls.Add(this.lblAngulo2);
            this.Controls.Add(this.lblAngulo1);
            this.Name = "FrmAngulos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Triângulos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAngulo1;
        private System.Windows.Forms.Label lblAngulo2;
        private System.Windows.Forms.Label lblAngulo3;
        private System.Windows.Forms.TextBox txtAngulo1;
        private System.Windows.Forms.TextBox txtAngulo2;
        private System.Windows.Forms.TextBox txtAngulo3;
        private System.Windows.Forms.Button btnClassificar;
        private System.Windows.Forms.Label lblResultado;
    }
}

