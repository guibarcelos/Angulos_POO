﻿using System;
using System.Windows.Forms;

namespace Angulos
{
    public partial class FrmAngulos : Form
    {
        public FrmAngulos()
        {
            InitializeComponent();
        }

        private void btnClassificar_Click(object sender, EventArgs e)
        {
            //Entrada de dados
            double a1 = double.Parse(txtAngulo1.Text);
            double a2 = double.Parse(txtAngulo2.Text);
            double a3 = double.Parse(txtAngulo3.Text);


            //if (a1 + a2 + a3 != 180)
            //{
            //    lblResultado.Text = "Triângulo inválido.";
            //}
            //else if (a1 == 0 || a2 == 0 || a3 == 0)
            //{
            //    lblResultado.Text = "Triângulo inválido.";
            //}

            if (a1 + a2 + a3 != 180 || a1 == 0 || a2 == 0 || a3 == 0)
            {
                lblResultado.Text = "Triângulo inválido.";
            }
            else
            {
                if (a1 == 90 || a2 == 90 || a3 == 90)
                {
                    lblResultado.Text = "Triângulo RETÂNGULO.";
                }
                else if (a1 > 90 || a2 > 90 || a3 > 90)
                {
                    lblResultado.Text = "Triângulo OBTUSÂNGULO.";
                }
                else if (a1 < 90 && a2 < 90 && a3 < 90)
                {
                    lblResultado.Text = "Triângulo ACUTÂNGULO.";
                }
            }
        }
    }
}
